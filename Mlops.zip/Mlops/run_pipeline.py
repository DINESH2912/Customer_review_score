from pipelines.training_pipeline import train_pipeline

if __name__=="__main__":

    train_pipeline(data_path=r"C:\Users\DINESH\Dropbox\PC\Desktop\Mlops\data\olist_customers_dataset.csv")