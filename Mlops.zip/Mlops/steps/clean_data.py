import logging
import pandas as pd
from zenml import step
from src.data_cleaning import DataCleaning, DataDivideStrategy, DataPreprocessStartegy
from typing_extensions import Annotated 
from typing import Tuple

@step
def clean_data1(df: pd.DataFrame) -> Tuple[
    Annotated[pd.DataFrame, "x_train"],
    Annotated[pd.DataFrame, "x_test"],
    Annotated[pd.DataFrame, "y_train"],
    Annotated[pd.DataFrame, "y_test"],
]:
    try:
        process_strategy = DataPreprocessStartegy()
        data_cleaning = DataCleaning(df, process_strategy)
        processed_data = data_cleaning.handle_data()

        divide_strategy = DataDivideStrategy()
        data_cleaning = DataCleaning(processed_data, divide_strategy)
        
        # Assuming handle_data() returns x_train, x_test, y_train, y_test as DataFrames
        x_train, x_test, y_train, y_test = data_cleaning.handle_data()
        
        # Ensure that 'y_train' and 'y_test' are converted to DataFrames if they are Series
        y_train = pd.DataFrame(y_train)
        y_test = pd.DataFrame(y_test)
        
        return x_train, x_test, y_train, y_test

    except Exception as e:
        logging.error("Error in cleaning data: {}".format(e))
        raise e
